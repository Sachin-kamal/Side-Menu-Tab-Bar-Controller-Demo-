//
//  SwiftUI_DemoApp.swift
//  SwiftUI_Demo
//
//  Created by Techsaga Corp on 17/09/21.
//

import SwiftUI

@main
struct SwiftUI_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
